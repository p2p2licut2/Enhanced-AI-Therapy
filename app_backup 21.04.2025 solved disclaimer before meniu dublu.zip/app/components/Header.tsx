'use client';

import React, { useState, useRef, useEffect } from 'react';
import Image from 'next/image';
import { useApp } from '@/app/contexts/AppContext';

export default function Header() {
  const {
    currentTherapist,
    setIsMenuOpen,
    toggleFavorite,
    currentConversation,
    isCurrentConversationFavorite,
    renameConversation,
    deleteConversation
  } = useApp();

  const [showOptions, setShowOptions] = useState(false);
  const [isRenaming, setIsRenaming] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const optionsRef = useRef<HTMLDivElement>(null);
  const titleInputRef = useRef<HTMLInputElement>(null);
  const titleScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = titleScrollRef.current;
    if (!el) return;
  
    const updateFade = () => {
      // dacă am ajuns (aproape) la capăt, ascunde fade‑ul
      if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 1) {
        el.classList.add('fade-hidden');
      } else {
        el.classList.remove('fade-hidden');
      }
    };
  
    // rulează o dată la mount (mai ales când titlul e scurt)
    updateFade();
  
    el.addEventListener('scroll', updateFade);
    return () => el.removeEventListener('scroll', updateFade);
  }, [currentConversation?.id]);   // rulează din nou când schimb conversația

  useEffect(() => {
    const handleClickOutside = (e: globalThis.MouseEvent) => {
      if (optionsRef.current && e.target instanceof Node) {
        if (!optionsRef.current.contains(e.target)) {
          setShowOptions(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    // Focus the input when renaming starts
    if (isRenaming && titleInputRef.current) {
      titleInputRef.current.focus();
    }
  }, [isRenaming]);

  // Reset new title when conversation changes
  useEffect(() => {
    if (currentConversation) {
      setNewTitle(currentConversation.title);
    }
    setIsRenaming(false);
    setShowOptions(false);
  }, [currentConversation]);

  const handleMenuClick = () => {
    setIsMenuOpen(true);
  };

  const handleFavoriteClick = () => {
    if (currentConversation) {
      toggleFavorite(currentConversation.id);
    }
  };

  const handleTitleClick = () => {
    if (currentConversation) {
      setShowOptions(!showOptions);
    }
  };

  const handleRename = () => {
    setIsRenaming(true);
    setShowOptions(false);
  };

  const handleDelete = () => {
    if (currentConversation) {
      if (window.confirm('Ești sigur că vrei să ștergi această conversație?')) {
        deleteConversation(currentConversation.id);
      }
    }
    setShowOptions(false);
  };

  const handleRenameSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (currentConversation && newTitle.trim()) {
      renameConversation(currentConversation.id, newTitle.trim());
      setIsRenaming(false);
    }
  };

  const handleRenameCancel = () => {
    setIsRenaming(false);
    setNewTitle(currentConversation?.title || '');
  };

  return (
    <div className="global-header">
      <div className="header-content">
        <div className="header-left flex items-center flex-1 min-w-0">
          <button
            className="header-menu-button"
            onClick={handleMenuClick}
            aria-label="Open menu"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-6 h-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>

          <div className="header-icon">
            <Image
              src={currentTherapist.avatarSrc}
              alt={currentTherapist.name}
              width={40}
              height={40}
              className="rounded-full object-cover"
            />
          </div>

          <div className="header-title-container flex flex-col min-w-0">
            <div className="header-title truncate">
              {currentTherapist.name} - {currentTherapist.title}
            </div>

            {currentConversation && !isRenaming && (
              <div className="scroll-fade flex-1 min-w-0 pr-2">
              <div
              ref={titleScrollRef}
              onClick={handleTitleClick}
              /* clase Tailwind: scroll orizontal + text pe o singură linie + ascunde bara */
              className="overflow-x-auto whitespace-nowrap no-scrollbar cursor-pointer"
              >
                {currentConversation.title}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  className="w-3 h-3 ml-1 inline-block"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </div>
              </div>
            )}

            {currentConversation && isRenaming && (
              <form onSubmit={handleRenameSubmit} className="rename-form">
                <input
                  ref={titleInputRef}
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="rename-input flex-1 min-w-0 truncate"
                  placeholder="Introdu un nou titlu"
                />
                <div className="rename-actions">
                  <button type="submit" className="rename-save-btn">
                    Salvează
                  </button>
                  <button
                    type="button"
                    onClick={handleRenameCancel}
                    className="rename-cancel-btn"
                  >
                    Anulează
                  </button>
                </div>
              </form>
            )}

            {showOptions && (
              <div className="title-options" ref={optionsRef}>
                <div className="title-option" onClick={handleRename}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    className="w-4 h-4 mr-2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                    />
                  </svg>
                  Redenumește
                </div>
                <div className="title-option title-option-delete" onClick={handleDelete}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    className="w-4 h-4 mr-2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                    />
                  </svg>
                  Șterge
                </div>
              </div>
            )}
          </div>
        </div>

        {currentConversation && (
          <button
            className="favorite-button"
            onClick={handleFavoriteClick}
            aria-label={isCurrentConversationFavorite ? "Remove from favorites" : "Add to favorites"}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill={isCurrentConversationFavorite ? "currentColor" : "none"}
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-6 h-6"
              style={{ color: isCurrentConversationFavorite ? '#FFD700' : '#C17F65' }}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
              />
            </svg>
          </button>
        )}
      </div>
    </div>
  );
}